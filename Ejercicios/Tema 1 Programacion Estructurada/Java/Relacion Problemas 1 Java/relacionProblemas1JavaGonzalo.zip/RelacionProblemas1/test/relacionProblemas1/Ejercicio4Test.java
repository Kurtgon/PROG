package relacionProblemas1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class Ejercicio4Test {
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
	private final PrintStream originalOut = System.out;
	private final PrintStream originalErr = System.err;

	@BeforeEach
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	    System.setErr(new PrintStream(errContent));
	}

	@AfterEach
	public void restoreStreams() {
	    System.setOut(originalOut);
	    System.setErr(originalErr);
	    System.setIn(System.in);
	}
	
	@ParameterizedTest
	@MethodSource("parametros")
	void withMethodSource(String numero, String respuesta) {
		ByteArrayInputStream in = new ByteArrayInputStream(numero.getBytes());
		System.setIn(in);
		Ejercicio4.main(null);
		assertEquals(respuesta,outContent.toString());
	}
	
	private static Stream<Arguments> parametros() {
		return Stream.of(
				Arguments.of("0","Introduzca la edad de la persona:\r\nEs un ni�o\r\n"),
				Arguments.of("10","Introduzca la edad de la persona:\r\nEs un ni�o\r\n"),
				Arguments.of("12","Introduzca la edad de la persona:\r\nEs un ni�o\r\n"),
				Arguments.of("13","Introduzca la edad de la persona:\r\nEs un adolescente\r\n"),
				Arguments.of("17","Introduzca la edad de la persona:\r\nEs un adolescente\r\n"),
				Arguments.of("19","Introduzca la edad de la persona:\r\nEs un joven\r\n"),
				Arguments.of("29","Introduzca la edad de la persona:\r\nEs un joven\r\n"),
				Arguments.of("30","Introduzca la edad de la persona:\r\nEs un adulto\r\n"));
	}
}
