package relacionProblemas1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class Ejercicio6Test {
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
	private final PrintStream originalOut = System.out;
	private final PrintStream originalErr = System.err;

	@BeforeEach
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	    System.setErr(new PrintStream(errContent));
	}

	@AfterEach
	public void restoreStreams() {
	    System.setOut(originalOut);
	    System.setErr(originalErr);
	    System.setIn(System.in);
	}
	
	@ParameterizedTest
	@MethodSource("parametros")
	void withMethodSource(String caracter, String respuesta) {
		ByteArrayInputStream in = new ByteArrayInputStream(caracter.getBytes());
		System.setIn(in);
		Ejercicio6.main(null);
		assertEquals(respuesta,outContent.toString());
	}
	
	private static Stream<Arguments> parametros() {
		return Stream.of(
				Arguments.of("a","Introduzca un car�cter:\r\nEl car�cter introducido es una vocal\r\nEs la primera vocal (A)\r\n"),
				Arguments.of("E","Introduzca un car�cter:\r\nEl car�cter introducido es una vocal\r\nEs la segunda vocal (E)\r\n"),
				Arguments.of("i","Introduzca un car�cter:\r\nEl car�cter introducido es una vocal\r\nEs la tercera vocal (I)\r\n"),
				Arguments.of("O","Introduzca un car�cter:\r\nEl car�cter introducido es una vocal\r\nEs la cuarta vocal (O)\r\n"),
				Arguments.of("u","Introduzca un car�cter:\r\nEl car�cter introducido es una vocal\r\nEs la quinta vocal (U)\r\n"),
				Arguments.of("d","Introduzca un car�cter:\r\nEl car�cter introducido no es una vocal\r\n"),
				Arguments.of("*","Introduzca un car�cter:\r\nEl car�cter introducido no es una vocal\r\n"));
	}
}
