package relacionProblemas1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class Ejercicio8Test {
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
	private final PrintStream originalOut = System.out;
	private final PrintStream originalErr = System.err;

	@BeforeEach
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	    System.setErr(new PrintStream(errContent));
	}

	@AfterEach
	public void restoreStreams() {
	    System.setOut(originalOut);
	    System.setErr(originalErr);
	    System.setIn(System.in);
	}
	
	@ParameterizedTest
	@MethodSource("parametros")
	void withMethodSource(String hora1, String minutos1, String segundos1,String hora2, String minutos2, String segundos2,String respuesta) {
		String horas = hora1+"\n"+minutos1+"\n"+segundos1+"\n"+hora2+"\n"+minutos2+"\n"+segundos2;
		ByteArrayInputStream in = new ByteArrayInputStream(horas.getBytes());
		System.setIn(in);
		Ejercicio8.main(null);
		assertEquals(respuesta,outContent.toString());
	}
	
	private static Stream<Arguments> parametros() {
		return Stream.of(
				Arguments.of("12","5","0","12","5","0","Introduce la primera marcaci�n (hora INTRO minutos INTRO segundos INTRO):\r\nIntroduce la segunda marcaci�n (hora INTRO minutos INTRO segundos INTRO):\r\nHora 1 es igual que Hora 2\r\n"),
				Arguments.of("12","50","0","12","5","0","Introduce la primera marcaci�n (hora INTRO minutos INTRO segundos INTRO):\r\nIntroduce la segunda marcaci�n (hora INTRO minutos INTRO segundos INTRO):\r\nHora 1 es mayor que Hora 2\r\n"),
				Arguments.of("12","5","50","12","6","0","Introduce la primera marcaci�n (hora INTRO minutos INTRO segundos INTRO):\r\nIntroduce la segunda marcaci�n (hora INTRO minutos INTRO segundos INTRO):\r\nHora 2 es mayor que Hora 1\r\n"),
				Arguments.of("54","5","0","12","5","0","Introduce la primera marcaci�n (hora INTRO minutos INTRO segundos INTRO):\r\nHora no correcta\r\n"),
				Arguments.of("12","54","0","12","90","0","Introduce la primera marcaci�n (hora INTRO minutos INTRO segundos INTRO):\r\nIntroduce la segunda marcaci�n (hora INTRO minutos INTRO segundos INTRO):\r\nHora no correcta\r\n"));
	}
}
