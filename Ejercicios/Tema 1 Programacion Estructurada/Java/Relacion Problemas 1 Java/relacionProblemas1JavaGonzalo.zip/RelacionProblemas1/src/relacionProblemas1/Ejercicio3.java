package relacionProblemas1;

import java.util.Scanner;

public class Ejercicio3 {
	// Constantes
		

	public static void main(String[] args) {
		//Realizar un programa que lea un n�mero por teclado. El programa debe
		//imprimir en pantalla un mensaje con " El n�mero xx es m�ltiplo de 2" o un
		//mensaje con "El n�mero xx es m�ltiplo de 3". Si es m�ltiplo de 2 y de 3
		//deben aparecer los dos mensajes. Si no es m�ltiplo de ninguno de los dos
		//el programa finaliza sin mostrar ning�n mensaje.
		//Cuestiones para que pase los test:
		// En el caso de que muestre los dos mensajes, debe mostrar primero que es m�ltiplo de 2 y luego de 3
		// El n�mero se debe pedir con el mensaje "Introduzca un n�mero:"

		
		// Variables
				int num;
		//Inicio
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Introduzca un n�mero:");
		num = sc.nextInt();
		
		if(num%2==0) {
			System.out.println("El n�mero "+ num + " es m�ltiplo de 2");
		}
		
		if (num%3==0){
			System.out.println("El n�mero "+ num + " es m�ltiplo de 3");
		} 
		sc.close();
	}

}
