package relacionProblemas1;

import java.util.Scanner;

public class Ejercicio8 {
	// Constantes
	

	public static void main(String[] args) {
		/*
		 * Realizar un programa que lea por teclado dos marcaciones de un reloj
		 * digital (horas, minutos, segundos) comprendidas entre las 0:0:0 y las
		 * 23:59:59 e informe cual de ellas es mayor.
		 * Cuestiones para que pase los test:
		 * Para solicitar la primera fecha debe decir ""Introduce la primera marcaci�n (hora INTRO minutos INTRO segundos INTRO):"
		 * Si la fecha no es adecuada escribir "Hora no correcta" y terminar.
		 * Para solicitar la segunda fecha debe decir ""Introduce la segunda marcaci�n (hora INTRO minutos INTRO segundos INTRO):"
		 * Si la fecha no es adecuada escribir "Hora no correcta" y terminar.
		 * La salida debe ser
		 * "Hora 1 es mayor que Hora 2"
		 * "Hora 2 es mayor que Hora 1"
		 * "Hora 1 es igual que Hora 2"

		 */

		
		// Variables
		int hora1, minutos1, segundos1,hora2, minutos2, segundos2;
		int resultado1=0, resultado2=0;
		
		Scanner sc = new Scanner(System.in);
		
		// Inicio
		
		System.out.println("Introduce la primera marcaci�n (hora INTRO minutos INTRO segundos INTRO):");
		hora1=Integer.parseInt(sc.nextLine());
		minutos1=Integer.parseInt(sc.nextLine());
		segundos1=Integer.parseInt(sc.nextLine());
		
		if (hora1>=0 && hora1<=23 && minutos1>=0 && minutos1 <=59 && segundos1>=0 && segundos1<=59) {
		
				resultado1=hora1*3600+minutos1*60+segundos1;	
			
		
		System.out.println("Introduce la segunda marcaci�n (hora INTRO minutos INTRO segundos INTRO):");
		hora2=Integer.parseInt(sc.nextLine());
		minutos2=Integer.parseInt(sc.nextLine());
		segundos2=Integer.parseInt(sc.nextLine());
					
		if (hora2>=0 && hora2<=23 && minutos2>=0 && minutos2 <=59 && segundos2>=0 && segundos2<=59) {
														
				resultado2=hora2*3600+minutos2*60+segundos2;
			
								
				if(resultado2==resultado1) {
						
					System.out.println("Hora 1 es igual que Hora 2");
						}
								
				if(resultado1>resultado2) {
					
					System.out.println("Hora 1 es mayor que Hora 2");
						}
				if(resultado2>resultado1) {
					
					System.out.println("Hora 2 es mayor que Hora 1");
						}					
			}else {
				System.out.println("Hora no correcta");
			}
		}else {
			
			System.out.println("Hora no correcta");
		}
		
		sc.close();
	}

}
