package relacionProblemas1;
import java.util.Scanner;

public class Ejercicio1 {

	
	
	public static void main(String[] args) {
		//Realizar un programa que lea un n�mero entero por teclado e informe de si
		//el número es par o impar (el cero se considera par).
		// Cuestiones para que pase los test:
		// Para pedir el n�mero debe mostrar el mensaje exacto "Introduzca un n�mero:"
		// Debe responder "El n�mero es par" o "El n�mero es impar"
		
		// Variables
		int num;
			
		//Inicio
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Introduzca un n�mero:");
		num = sc.nextInt();
		
		if (num%2==0) {
			
			System.out.println("El n�mero es par");
		}
		else {
			
			System.out.println("El n�mero es impar");
		}
		
		sc.close();
			
	}

}


//Introduzca un n�mero: 