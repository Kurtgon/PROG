package relacionProblemas1;

import java.util.Scanner;

public class Ejercicio7 {

	public static void main(String[] args) {
		/*
		 * Realizar un programa que lea el estado civil de una persona (S-Soltero, C-
		 * Casado, V-Viudo y D-Divorciado) y su edad. Despu�s debe mostrar por pantalla
		 * el porcentaje de retenci�n que debe aplic�rsele de acuerdo con las siguientes
		 * reglas: 
		 		* A los solteros o divorciados menores de 35 a�os, un 12% 
		 		* Todas las personas mayores de 50 a�os, un 8.5% 
		 		* A los viudos o casados menores de 35 a�os, un 11.3% 
		 		* Al resto de casos se le aplica un 10.5%
		 * Cuestiones para que pasen los test:
		 * Se solicita el car�cter con el mensaje: "Introduzca el estado civil (S-Soltero, C-Casado, V-Viudo, D-Divorciado):"
		 * Se solicita la edad con el mensaje: "Introduzca la edad (0-100):"
		 * Seg�n sea el caso:
		 * "El porcentaje a aplicar es: 8.5%"
		 * Obviamente seg�n el caso mostrar� el n�mero correspondiente
		 * Primero debe comprobar si la edad est� comprendida entre 0 y 100. Si no lo cumple, debe mostrar el mensaje:
		 * "La edad introducida no es v�lida"
		 * Luego comprobar� si el estado civil no es v�lido, en cuyo caso debe mostrar el mensaje
		 * "Estado civil incorrecto"
		 */
		
		// Variables
		char estado;
		int edad;
		double porcentaje;
		porcentaje=0;
		
		// Inicio
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Introduzca el estado civil (S-Soltero, C-Casado, V-Viudo, D-Divorciado):");
		estado=sc.nextLine().charAt(0);
		System.out.println("Introduzca la edad (0-100):");
		edad=sc.nextInt();
		
		if (edad>=0 && edad<=100) {
			
			if (estado=='S' || estado=='C' || estado=='V' || estado=='D') {
				
				if (edad>50) {
					 porcentaje=8.5;
				}
				else {
					if(edad>=35) {
						porcentaje=10.5;
					}
					else {	
						if(estado=='S' || estado=='D') {
							porcentaje=12;
						}
						else {
							porcentaje=11.3;
						}
					}
				}
				
				System.out.println("El porcentaje a aplicar es: " + porcentaje + "%");
			}
			else {
				System.out.println("Estado civil incorrecto");
			}
		}
		else {
			System.out.println("La edad introducida no es v�lida");
		}
		
		sc.close();
	}
}

