package relacionProblemas1;

import java.util.Scanner;

public class Ejercicio9 {
	// Constantes


	public static void main(String[] args) {
		/*
		 * En un establecimiento en rebajas, hay 3 tipos de productos (A, B y C). 
		 * El porcentaje de rebaja que se aplicar� sobre el precio original del
		 * producto se calcula de la siguiente forma:
		 		* Si el producto es de tipo A, independientemente de su precio se aplica un 7% de descuento.
		 		* Si el producto es de tipo C o bien el precio es inferior a 500��se aplicar� un porcentaje del 12% de descuento.
		 		* En el resto de casos se aplica un 9% de descuento.
		 * Realizar un programa que solicite los datos necesarios 
		 * (tipo de producto y precio original) y calcule el precio rebajado.
		 * Debe comprobarse que los datos de entrada son correctos, y si no lo 
		 * son mostrar un mensaje de error.
		 * Cuestiones para que pase los test:
		 * Para pedir el tipo del producto se deber� escribir "Introduzca el tipo de producto (A, B, C):"
		 * Si el tipo de producto no es correcto deber� decir "Producto no v�lido"
		 * Para solicitar el precio se deber� realizar con el mensaje "Introduzca el precio original:"
		 * Si el precio es menor que cero deber� aparecer el mensaje "Precio no v�lido"
		 * Para decir el precio rebajado debe decir "El precio original era xx y el rebajado es yy"
		 * 
		 */
		
		// Variables 
			char tipo;
			double precio=0;
			double rebaja=0;
			double porcentaje;
			
			Scanner sc = new Scanner(System.in);
		
		// Inicio del programa
		
			System.out.println("Introduzca el tipo de producto (A, B, C):");
			tipo=sc.nextLine().charAt(0);
			
			if (tipo =='A' || tipo=='B' || tipo=='C') {
				
				System.out.println("Introduzca el precio original:");
				precio=sc.nextDouble();
				
				if(precio<0) {
				
					System.out.println("Precio no v�lido");
				
				}else {
					
					switch(tipo) {
					
					case 'A':{
						
						porcentaje=precio*0.07;
						rebaja=precio-porcentaje;
						break;
					}
					case 'B':{
						
						if (precio>=500) {
						porcentaje=precio*0.09;
						rebaja=precio-porcentaje;
						}else{
						porcentaje=precio*0.12;
						rebaja=precio-porcentaje;
						}
						break;
					}
					case 'C':{
											
							porcentaje=precio*0.12;
							rebaja=precio-porcentaje;
						}						
						break;
					
					default:{
						
						System.out.println("El tipo no es v�lido");
						}
					}
					System.out.println("El precio original era " + precio + " y el rebajado es " + rebaja);
				}
			}else {
				
				System.out.println("Producto no v�lido");
			}	
			
			sc.close();
			
	}

}
