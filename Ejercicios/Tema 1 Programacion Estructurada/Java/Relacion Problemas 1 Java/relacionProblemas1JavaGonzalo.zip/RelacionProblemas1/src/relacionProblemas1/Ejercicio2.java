package relacionProblemas1;

import java.util.Scanner;

public class Ejercicio2 {
	public static void main(String[] args) {
		//Realizar un programa que solicite dos n�meros por teclado e imprima en
		//pantalla si son iguales, el primero mayor que el segundo o el primero m�s 
		//peque�o que el segundo.
		//Cuestiones para que pase los test:
		//Para pedir el n�mero debe mostrar el mensaje exacto "Introduzca un n�mero:"
		//Para pedie el segundo n�mero debe mostrar el mensaje exacto "Introduzca otro n�mero:"
		// Debe mostrar los siguientes mensajes seg�n el caso:
		//"El primer n�mero es mayor que el segundo"
		//"El primer n�mero es m�s peque�o que el segundo"
		//"Los dos n�meros son iguales"
		
		// Variables
		int num1,num2;
		//Inicio
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Introduzca un n�mero:");
		num1 = sc.nextInt();
		
		System.out.println("Introduzca otro n�mero:");
		num2 = sc.nextInt();
		
		if(num1==num2) {
			
			System.out.println("Los dos n�meros son iguales");
		}
			else if(num1>num2) {
			System.out.println("El primer n�mero es mayor que el segundo");
		}
			else {
			System.out.println("El primer n�mero es m�s peque�o que el segundo");
		}
		sc.close();
	}

}
