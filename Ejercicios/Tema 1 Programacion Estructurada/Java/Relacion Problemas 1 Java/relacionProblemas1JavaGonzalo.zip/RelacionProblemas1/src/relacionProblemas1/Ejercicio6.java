package relacionProblemas1;

import java.util.Scanner;


public class Ejercicio6 {

	public static void main(String[] args) {
		//Realizar un programa que solicite un car�cter por teclado e informe por
		//pantalla si el car�cter es una vocal o no lo es. Si es una vocal mostrar� el
		//mensaje "Es la primera vocal (A)" o "Es la segunda vocal (E)", etc.
		//Cuestiones para que pasen los test:
		//Se solicita el car�cter con el mensaje: "Introduzca un car�cter:"
		//Si es vocal muestra:
		//"El car�cter introducido es una vocal"
		//"Es la primera vocal (A)" Obviamente seg�n la vocal mostrar� el mensaje
		//Si no es vocal muestra:
		//"El car�cter introducido no es una vocal"
		
		// Variables
		char letra;

		// Inicio
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Introduzca un car�cter:");
		letra=sc.nextLine().charAt(0);
		letra=Character.toUpperCase(letra); //llamamos al m�todo para poner los car�cteres introducidos en May�sculas
		
		switch (letra) {
		
		case 'A':
			System.out.println("El car�cter introducido es una vocal");
			System.out.println("Es la primera vocal (A)");
			break;
			
		case 'E':
			System.out.println("El car�cter introducido es una vocal");
			System.out.println("Es la segunda vocal (E)");
			break;
			
		case 'I':
			System.out.println("El car�cter introducido es una vocal");
			System.out.println("Es la tercera vocal (I)");
			break;
			
		case 'O':
			System.out.println("El car�cter introducido es una vocal");
			System.out.println("Es la cuarta vocal (O)");
			break;
			
		case 'U':
			System.out.println("El car�cter introducido es una vocal");
			System.out.println("Es la quinta vocal (U)");
			break;
			
		default:
			System.out.println("El car�cter introducido no es una vocal");
			break;
		}
		sc.close();
		}

}
