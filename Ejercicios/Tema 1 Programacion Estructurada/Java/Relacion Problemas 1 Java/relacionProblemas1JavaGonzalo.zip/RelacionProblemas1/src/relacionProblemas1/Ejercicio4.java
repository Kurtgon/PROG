package relacionProblemas1;

import java.util.Scanner;

public class Ejercicio4 {
	// Constantes
		
		
		

	public static void main(String[] args) {
		//Realizar un programa que lea la edad de una persona menor a 100 años e
		//informe de si es un ni�o (0-12 años), un adolescente (13-17), un joven (18-
		//29) o un adulto.
		//Cuestiones para que pase los test:
		//Se solicita la edad con el mensaje "Introduzca la edad de la persona:"
		//Y responde con los mensajes siguientes seg�n el caso:
		//"Es un ni�o"
		//"Es un adolescente"
		//"Es un joven"
		//"Es un adulto"
		//NOTA: se supone que la edad es correcta, es decir es un entero entre 0 y 99

		
		// Variables
		int edad;
				
		//Inicio
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Introduzca la edad de la persona:");
		edad = sc.nextInt();
		
		if ((edad==0 || edad>0) && (edad==12 || edad<12)) {
			
			System.out.println("Es un ni�o");
		}
		
		if ((edad==13 || edad>13) && (edad==17 || edad<17)) {
			
			System.out.println("Es un adolescente");
		}
		
		if ((edad==18 || edad>18) && (edad==29 || edad<29)) {
			
			System.out.println("Es un joven");
		}
		if ((edad>29)&& (edad==99 || edad<99)) {
			System.out.println("Es un adulto");
		}
		sc.close();
	}

}
