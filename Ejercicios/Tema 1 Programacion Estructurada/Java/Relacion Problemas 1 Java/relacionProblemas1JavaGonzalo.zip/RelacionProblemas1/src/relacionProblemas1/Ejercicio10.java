package relacionProblemas1;

import java.util.Scanner;

public class Ejercicio10 {

	public static void main(String[] args) {
		/*
		 * Realizar un programa que lea un car�cter y dos n�meros enteros 
		 * por teclado. Si el car�ter le�do es un operador aritm�tico, 
		 * calcular la operaci�nn correspondiente, si es cualquier otro debe
		 * mostrar un error.
		 *  Cuestiones para que pase los test:
		 *  Para solicitar el primer n�mero se debe escribir "Introduzca el primer n�mero:"
		 *  Para solicitar el segundo n�mero se debe escribir "Introduzca el segundo n�mero:"
		 *  Para soicitar el operador se debe escribir "Introduzca el operador:"
		 *  Si el operador no es el adecuado (+ - / * ) debe decir "Operador no permitido"
		 *  El resultado debe aparecer de la forma "num1 operador num2 = resultado"
		 */
		
		// Variables
	int num1,num2;
	char operador;
	int resultado=0;	
		// Inicio
	
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Introduzca el primer n�mero:");
	num1 = Integer.parseInt(sc.nextLine());
	
	System.out.println("Introduzca el segundo n�mero:");
	num2= Integer.parseInt(sc.nextLine());
	
	System.out.println("Introduzca el operador:");
	operador=sc.nextLine().charAt(0);
	
	switch(operador) {
	
	case '+': {
		
		resultado= num1+num2;
		System.out.println(num1 + " " + operador + " " + num2 + " = " + resultado);
		break;
	}
	case '-':{
		
		resultado= num1-num2;
		System.out.println(num1 + " " + operador + " " + num2 + " = " + resultado);
		break;
	}
	case '*':{
		
		resultado= num1*num2;
		System.out.println(num1 + " " + operador + " " + num2 + " = " + resultado);
		break;
	}
	case '/':{
		
		resultado = num1/num2;
		System.out.println(num1 + " " + operador + " " + num2 + " = " + resultado);
		break;
	}
	default:{
		System.out.println("Operador no permitido");
		break;
	}
	}
	
	
	sc.close();
		
	}

}
