package loop;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import loop.Ejercicio1;

class Ejercicio1Test {
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
	private final PrintStream originalOut = System.out;
	private final PrintStream originalErr = System.err;

	@BeforeEach
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	    System.setErr(new PrintStream(errContent));
	}

	@AfterEach
	public void restoreStreams() {
	    System.setOut(originalOut);
	    System.setErr(originalErr);
	    System.setIn(System.in);
	}
	
	@ParameterizedTest
	@MethodSource("parametros")
	void withMethodSource(String numero, String respuesta) {
		ByteArrayInputStream in = new ByteArrayInputStream(numero.getBytes());
		System.setIn(in);
		Ejercicio1.main(null);
		assertEquals(respuesta,outContent.toString());
	}
	
	private static Stream<Arguments> parametros() {
		return Stream.of(
				Arguments.of("","1\r\n" + 
						"2\r\n" + 
						"3\r\n" + 
						"4\r\n" + 
						"5\r\n" + 
						"6\r\n" + 
						"7\r\n" + 
						"The number 7 is a multiple of 7\r\n" + 
						"8\r\n" + 
						"9\r\n" + 
						"10\r\n" + 
						"11\r\n" + 
						"12\r\n" + 
						"13\r\n" + 
						"The number 13 is a multiple of 13\r\n" + 
						"14\r\n" + 
						"The number 14 is a multiple of 7\r\n" + 
						"15\r\n" + 
						"16\r\n" + 
						"17\r\n" + 
						"18\r\n" + 
						"19\r\n" + 
						"20\r\n" + 
						"21\r\n" + 
						"The number 21 is a multiple of 7\r\n" + 
						"22\r\n" + 
						"23\r\n" + 
						"24\r\n" + 
						"25\r\n" + 
						"26\r\n" + 
						"The number 26 is a multiple of 13\r\n" + 
						"27\r\n" + 
						"28\r\n" + 
						"The number 28 is a multiple of 7\r\n" + 
						"29\r\n" + 
						"30\r\n" + 
						"31\r\n" + 
						"32\r\n" + 
						"33\r\n" + 
						"34\r\n" + 
						"35\r\n" + 
						"The number 35 is a multiple of 7\r\n" + 
						"36\r\n" + 
						"37\r\n" + 
						"38\r\n" + 
						"39\r\n" + 
						"The number 39 is a multiple of 13\r\n" + 
						"40\r\n" + 
						"41\r\n" + 
						"42\r\n" + 
						"The number 42 is a multiple of 7\r\n" + 
						"43\r\n" + 
						"44\r\n" + 
						"45\r\n" + 
						"46\r\n" + 
						"47\r\n" + 
						"48\r\n" + 
						"49\r\n" + 
						"The number 49 is a multiple of 7\r\n" + 
						"50\r\n" + 
						"51\r\n" + 
						"52\r\n" + 
						"The number 52 is a multiple of 13\r\n" + 
						"53\r\n" + 
						"54\r\n" + 
						"55\r\n" + 
						"56\r\n" + 
						"The number 56 is a multiple of 7\r\n" + 
						"57\r\n" + 
						"58\r\n" + 
						"59\r\n" + 
						"60\r\n" + 
						"61\r\n" + 
						"62\r\n" + 
						"63\r\n" + 
						"The number 63 is a multiple of 7\r\n" + 
						"64\r\n" + 
						"65\r\n" + 
						"The number 65 is a multiple of 13\r\n" + 
						"66\r\n" + 
						"67\r\n" + 
						"68\r\n" + 
						"69\r\n" + 
						"70\r\n" + 
						"The number 70 is a multiple of 7\r\n" + 
						"71\r\n" + 
						"72\r\n" + 
						"73\r\n" + 
						"74\r\n" + 
						"75\r\n" + 
						"76\r\n" + 
						"77\r\n" + 
						"The number 77 is a multiple of 7\r\n" + 
						"78\r\n" + 
						"The number 78 is a multiple of 13\r\n" + 
						"79\r\n" + 
						"80\r\n" + 
						"81\r\n" + 
						"82\r\n" + 
						"83\r\n" + 
						"84\r\n" + 
						"The number 84 is a multiple of 7\r\n" + 
						"85\r\n" + 
						"86\r\n" + 
						"87\r\n" + 
						"88\r\n" + 
						"89\r\n" + 
						"90\r\n" + 
						"91\r\n" + 
						"The number 91 is a multiple of 7\r\n" + 
						"The number 91 is a multiple of 13\r\n" + 
						"92\r\n" + 
						"93\r\n" + 
						"94\r\n" + 
						"95\r\n" + 
						"96\r\n" + 
						"97\r\n" + 
						"98\r\n" + 
						"The number 98 is a multiple of 7\r\n" + 
						"99\r\n" + 
						"100\r\n" + 
						""));
	}
	
}
