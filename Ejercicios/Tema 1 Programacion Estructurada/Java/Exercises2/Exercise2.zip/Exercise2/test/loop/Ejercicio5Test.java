package loop;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import loop.Ejercicio5;



class Ejercicio5Test {
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
	private final PrintStream originalOut = System.out;
	private final PrintStream originalErr = System.err;

	@BeforeEach
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	    System.setErr(new PrintStream(errContent));
	}

	@AfterEach
	public void restoreStreams() {
	    System.setOut(originalOut);
	    System.setErr(originalErr);
	    System.setIn(System.in);
	}
	
	@ParameterizedTest
	@MethodSource("parametros")
	void withMethodSource(String numero1,String numero2,String numero3, String respuesta) {
		String numero = numero1+"\n"+numero2+"\n"+numero3;
		ByteArrayInputStream in = new ByteArrayInputStream(numero.getBytes());
		System.setIn(in);
		Ejercicio5.main(null);
		assertEquals(respuesta,outContent.toString());
	}
	
	private static Stream<Arguments> parametros() {
		return Stream.of(
				Arguments.of("4","5","-1","Enter a number (negative to finish):\r\n" + 
						"Enter a number (negative to finish):\r\n" + 
						"Enter a number (negative to finish):\r\n" + 
						"You have entered 2 positive numbers.\r\n"),
				Arguments.of("0","0","-8","Enter a number (negative to finish):\r\n" + 
						"Enter a number (negative to finish):\r\n" + 
						"Enter a number (negative to finish):\r\n" + 
						"You have entered 0 positive numbers.\r\n"));
	}
	
}
