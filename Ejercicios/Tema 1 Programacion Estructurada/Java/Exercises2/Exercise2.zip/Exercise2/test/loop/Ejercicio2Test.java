package loop;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import loop.Ejercicio2;


class Ejercicio2Test {
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
	private final PrintStream originalOut = System.out;
	private final PrintStream originalErr = System.err;

	@BeforeEach
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	    System.setErr(new PrintStream(errContent));
	}

	@AfterEach
	public void restoreStreams() {
	    System.setOut(originalOut);
	    System.setErr(originalErr);
	    System.setIn(System.in);
	}
	
	@ParameterizedTest
	@MethodSource("parametros")
	void withMethodSource(String numero1,String numero2,String numero3, String respuesta) {
		String numero = numero1+"\n"+numero2+"\n"+numero3;
		ByteArrayInputStream in = new ByteArrayInputStream(numero.getBytes());
		System.setIn(in);
		Ejercicio2.main(null);
		assertEquals(respuesta,outContent.toString());
	}
	
	private static Stream<Arguments> parametros() {
		return Stream.of(
				Arguments.of("-1","11","7","Enter one number between 0 and 10\r\n" +  
						"The number is out of the boundaries\r\n" + 
						"Enter one number between 0 and 10\r\n" +
						"The number is out of the boundaries\r\n" + 
						"Enter one number between 0 and 10\r\n" + 
						"7*0=0\r\n" + 
						"7*1=7\r\n" + 
						"7*2=14\r\n" + 
						"7*3=21\r\n" + 
						"7*4=28\r\n" + 
						"7*5=35\r\n" + 
						"7*6=42\r\n" + 
						"7*7=49\r\n" + 
						"7*8=56\r\n" + 
						"7*9=63\r\n" + 
						"7*10=70\r\n" + 
						""),
				Arguments.of("0","","","Enter one number between 0 and 10\r\n" + 
						"0*0=0\r\n" + 
						"0*1=0\r\n" + 
						"0*2=0\r\n" + 
						"0*3=0\r\n" + 
						"0*4=0\r\n" + 
						"0*5=0\r\n" + 
						"0*6=0\r\n" + 
						"0*7=0\r\n" + 
						"0*8=0\r\n" + 
						"0*9=0\r\n" + 
						"0*10=0\r\n"),
				Arguments.of("10","","","Enter one number between 0 and 10\r\n" + 
						"10*0=0\r\n" + 
						"10*1=10\r\n" + 
						"10*2=20\r\n" + 
						"10*3=30\r\n" + 
						"10*4=40\r\n" + 
						"10*5=50\r\n" + 
						"10*6=60\r\n" + 
						"10*7=70\r\n" + 
						"10*8=80\r\n" + 
						"10*9=90\r\n" + 
						"10*10=100\r\n" + 
						""));
	}
	
}
