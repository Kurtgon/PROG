package loop;
import java.util.Scanner;

public class Ejercicio10 {

	public static void main(String[] args) {
		/*     10. Design a program that reads an integer positive number 
		 * and says the “factorial” of the number. To calculate the factorial
		 * you should know that
		 * FACT(0)= 1
		 * FACT(1) =1
		 * FACT(N)= N*(N-1)*(N-2)*....1
		 * The messages are the following:
		 * “Enter an integer positive number:”
		 * “The number is not valid, try again.”
		 * “The factorial is XX”
		 */
		
		// Variables
		
			int num,result,i;
		
		// Inicio
		
			Scanner sc = new Scanner(System.in);
			
			result=1;
			
			do {
				
				System.out.println("Enter an integer positive number:");
				num=Integer.parseInt(sc.nextLine());
				
				if (num<0) {
					
					System.out.println("The number is not valid, try again.");
				}
			}
			while (num<0);
			
			for (i=1; i<=num; i++) {
				
				result=result*i;
			}
			
			System.out.println("The factorial is " + result);
			
			sc.close();
		
	}

}
