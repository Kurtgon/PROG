package loop;
import java.util.Scanner;

public class Ejercicio7 {

	public static void main(String[] args) {
		/*        7. Design a program that asks how many numbers the user 
		 * wants to write. After the user enters all numbers, the program 
		 * should say the medium of the numbers. If the user inputs a wrong 
		 * number, the program should ask for it again. The messages are the 
		 * following:
		 * “How many numbers do you want input?” to ask for the number of numbers.
		 * “Enter one number greater than 0:” to ask for a number.
		 * “The number is not valid, it should be greater than 0” to inform that the number is not valid.
		 * “The medium is XX.XX” to show the result.
		 */
		
		// Variables
		int num1,num2,i;
		double suma,media;
		
		
		// Inicio
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("How many numbers do you want input?");
		num1 = Integer.parseInt(sc.nextLine());
		
		suma=0;
		
		
		for(i=1; i<=num1; i++) {
			
			System.out.println("Enter one number greater than 0:");
			num2 = Integer.parseInt(sc.nextLine());	
			
			while (num2<=0) {
						
				System.out.println("The number is not valid, it should be greater than 0");
				System.out.println("Enter one number greater than 0:");
				num2 = Integer.parseInt(sc.nextLine());	
			}
			suma=suma+num2;			
		}
		media=suma/num1;
		System.out.println("The medium is " + media);
		
		sc.close();
	}

}
