package loop;
import java.util.Scanner;

public class Ejercicio6 {

	public static void main(String[] args) {
		/*     6. Design a program that reads two integer numbers, for 
		 * example numberA and numberB, and calculates the product of both 
		 * numbers without use multiplication, but using the sum. The 
		 * messages are the following:
		 * “Enter one number:”
		 * “The product is XX”
		 */
		
		// Variables
			int num1, num2, result, i;
			
		// Inicio
		
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter one number:");
			num1=Integer.parseInt(sc.nextLine());
			
			System.out.println("Enter one number:");
			num2=Integer.parseInt(sc.nextLine());
			
			result=0;
			
			for(i=1; i<=num2; i++) {
				
				result=result + num1;
			}
			
			System.out.println("The product is " + result);
	
			sc.close();
	}

}
