package loop;
import java.util.Scanner;

public class Ejercicio9 {

	public static void main(String[] args) {
		/*    9. Design a program that reads an integer positive number 
		 * greater than 0 and says if it’s a “perfect number”. A number is 
		 * perfect if it is equal to the sum of all its divisors. The 
		 * messages are the following:
		 * “Enter an integer positive number greater than 0:”
		 * “The number is not valid, try again.”
		 * “The number is perfect.”
		 * “The number is not perfect.”
		 */
		
		// Variables
			int num,result, i;
			
		// Inicio
		
			Scanner sc = new Scanner(System.in);
			
			result=0;
			
			do {
				System.out.println("Enter an integer positive number greater than 0:");
				num=Integer.parseInt(sc.nextLine());
				
				if (num <=0) {
					
					System.out.println("The number is not valid, try again.");
				}			
			}
			while (num<=0);
			
			for(i=1; i<=num-1; i++) {
				
				if(num%i==0) {
					
					result= result+i;
				}
			}

			if(result==num) {
				
				System.out.println("The number is perfect.");
			}
			else {
				
				System.out.println("The number is not perfect.");
			}
			
			sc.close();
	}

}
