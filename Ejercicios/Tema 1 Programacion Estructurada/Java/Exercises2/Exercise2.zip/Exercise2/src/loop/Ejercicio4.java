package loop;
import java.util.Scanner;

public class Ejercicio4 {

	public static void main(String[] args) {
		/*     4. Design a program that reads a positive number N greater 
		 * than 0 and show the result of the sum of the N numbers between 1 
		 * and N. If the number N is not valid, the program should ask for it 
		 * again. The messages are the following:
	 	 * “Enter one number greater than 0:”
		 * “The number is not right, try again.”
		 * “The sum of the N first numbers is XX.”
		 */
		
		// Variables
			
			int num,i, result;
		
		// Inicio
		
			Scanner sc = new Scanner(System.in);
			
			do {
				System.out.println("Enter one number greater than 0:");
				num = Integer.parseInt(sc.nextLine());
				
				if (num <=0) {
					
					System.out.println("The number is not right, try again.");
				}
				
			}
			while (num <=0);
			result=0;
			
			for(i=1; i<=num; i++) {
				
				result= result +i;
			}
			
			System.out.println("The sum of the N first numbers is " + result + ".");
			
			sc.close();
	}

}
