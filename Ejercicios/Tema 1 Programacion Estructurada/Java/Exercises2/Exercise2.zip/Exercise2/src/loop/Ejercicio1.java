package loop;


public class Ejercicio1 {

	public static void main(String[] args) {
		/* Design a program to show all numbers between 1 and 100. If the 
		 * number is a multiple of 7 you should show the message 
		 * "The number xx is a multiple of 7". If the number is a multiple 
		 * of 13 you should show the message 
		 * "The number xx is a multiple of 13". If the number is a multiple 
		 * of 7 and 13 you should show both messages.
		 */
		
		
		// Variables
		
		int num;
		int counter=0;
		
		// Inicio
				
		for(num=1; num<=100;num++) {
			counter++;
			System.out.println(counter);
			
			if(counter%7==0) {
				System.out.println("The number " + counter + " is a multiple of 7");
			}
			
			if(counter%13==0) {
				System.out.println("The number " + counter + " is a multiple of 13");
			}
		}
	}

}
