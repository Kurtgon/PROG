package loop;

import java.util.Scanner;

public class Ejercicio3 {

	public static void main(String[] args) {
		/* Design a program that asks how many numbers the user wants 
		 * to introduce. Then, the user would have to introduce the numbers 
		 * one by one and the program should say if each one of the numbers 
		 * is odd or even. If the user inputs 0 or a negative number, it is 
		 * not valid, and the system should ask for another number. The 
		 * messages are the following:
		 * “How many numbers do you want input?” to ask for the number of numbers.
		 * “Enter one number greater than 0:” to ask for a number.
		 * “The number is not valid, it should be greater than 0” to inform that the number is not valid.
		 * “The number XX is odd”
		 * “The number XX is even”
		*/
		
		// Variables
		
		int num1,num2,i;
		
		Scanner sc = new Scanner(System.in);
				
		// Inicio
		
		System.out.println("How many numbers do you want input?");
		num1=Integer.parseInt(sc.nextLine());
		
		for(i=1; i<=num1; i++) {
			
			System.out.println("Enter one number greater than 0:");
			num2=Integer.parseInt(sc.nextLine());
			
			while (num2 <=0) {
				
				System.out.println("The number is not valid, it should be greater than 0");
				System.out.println("Enter one number greater than 0:");
				num2=Integer.parseInt(sc.nextLine());
			}
			
			if(num2%2==0) {
				System.out.println("The number " + num2 + " is even");
			}else {
				System.out.println("The number " + num2 + " is odd");
			}
		}
		
			sc.close();
	}

}
