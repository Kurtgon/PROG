package loop;
import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		/*     2. Design a program for reading an integer between 0 and 10 
		 * and show the times table. To ask for the number you should show 
		 * the next message "Enter one number between 0 and 10”. If the 
		 * number is out of the boundaries, the program should show the 
		 * message “The number is out of the boundaries”. If the number is 
		 * valid, it should show the times table following the next format:
         *  7*0=0
         *  7*1=7
         *  …..
         *  7*10=70
		 */
		
		// Variables
		
		int num,contador;
		
		Scanner sc = new Scanner(System.in);
		
		// Inicio
		
			System.out.println("Enter one number between 0 and 10");
			num=Integer.parseInt(sc.nextLine());
		
		
		
		while(num<0 || num>10) {
			
			System.out.println("The number is out of the boundaries");
			System.out.println("Enter one number between 0 and 10");
			num=Integer.parseInt(sc.nextLine());
		}
		
		if(num>=0 && num<=10) {
			
			for (contador=0; contador<=10; contador++) {
				
				System.out.println(num + "*" + contador + "=" + num*contador );
			}
			
		}
		
		sc.close();
	}

}
