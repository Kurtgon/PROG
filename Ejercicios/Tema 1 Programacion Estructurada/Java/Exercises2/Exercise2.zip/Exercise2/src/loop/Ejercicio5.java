package loop;
import java.util.Scanner;

public class Ejercicio5 {

	public static void main(String[] args) {
		/*     5. Design a program that asks for numbers until the user 
		 * inputs a negative one. When this happens, the program will show 
		 * how many positive numbers have been introduced by the user. The 
		 * messages are the following:
 		 * “Enter a number (negative to finish):” 
		 * “You have entered XX positive numbers.”
		 */
		
		// Variables
			
			int num, cont;
		
		// Inicio
		
			Scanner sc = new Scanner(System.in);
			
			cont=0;
			
			do {
				
				System.out.println("Enter a number (negative to finish):");
				num = Integer.parseInt(sc.nextLine());
				
				if (num>0) {
					
					cont=cont+1;
				}
				
			}
			while(num>=0);
			
			System.out.println("You have entered " + cont + " positive numbers.");
			
			sc.close();

	}

}
