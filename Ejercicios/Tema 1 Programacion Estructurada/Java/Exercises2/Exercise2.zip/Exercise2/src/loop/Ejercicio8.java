package loop;
import java.util.Scanner;

public class Ejercicio8 {
	
	private static final int VALORMAX=999999999;

	public static void main(String[] args) {
		/*     8. Design a program that asks for a set of numbers. After 
		 * inputting each number, the program should ask “Do you want to 
		 * enter more numbers (Y/N)?”. If the answer is “Y” the program asks
		 * for other numbers. When the user finishes to enter all the numbers,
		 * the program should say which one is the smallest. The messages 
		 * are the following:
		 * “Enter one number:”
		 * “Do you want to enter more number (Y/N)?”
		 * “The smallest number is XX”
		 */
		
		// Variables
	
		int num, resultado;
		char respuesta;
				
		// Inicio
	
		Scanner sc = new Scanner(System.in);
		
		resultado = VALORMAX;
		
		do {
			
			System.out.println("Enter one number:");
			num=Integer.parseInt(sc.nextLine());
		
			if(num<resultado) {
				resultado=num;
			}
		
			System.out.println("Do you want to enter more number (Y/N)?");
			respuesta=sc.nextLine().charAt(0);
		}while(respuesta=='Y');
	
		System.out.println("The smallest number is " + resultado );
		
		sc.close();
		
	}

}
