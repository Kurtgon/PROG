package EjerciciosBucles;

public class Ejercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num=0;
			
			for(int i=1; i<=10; i++) {
				num=num+3;
				System.out.println(num);
			}
		}

}
