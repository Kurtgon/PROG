package EjerciciosBucles;

import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num1=1;
		int num2;
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Introduzca un n�mero: ");
		num2=Integer.parseInt(sc.nextLine());
		
		for(int i=num1; i<num2+1; i++) {
		
		System.out.println(num1);
		num1=num1+1;
		}
		sc.close();
		

	}

}
