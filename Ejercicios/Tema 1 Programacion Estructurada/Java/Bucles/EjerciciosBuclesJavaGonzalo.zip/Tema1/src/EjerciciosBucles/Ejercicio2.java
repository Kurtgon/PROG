package EjerciciosBucles;

import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num1;
		int num2;
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Introduzca un n�mero: ");
		num1=Integer.parseInt(sc.nextLine());
		
		System.out.println("Introduzca un n�mero: ");
		num2=Integer.parseInt(sc.nextLine());
		
		if (num1>num2) {
			
			for(int i=num2;i<=num1;i++) {
			System.out.println(num2);
			num2++;
			}
		
		}else {
			
			for(int i=num1;i<=num2;i++) {
				System.out.println(num1);
				num1++;
			}
		}
	
		sc.close();

	}

}



