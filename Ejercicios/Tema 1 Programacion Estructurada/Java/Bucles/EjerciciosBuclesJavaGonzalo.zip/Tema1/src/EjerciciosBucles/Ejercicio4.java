package EjerciciosBucles;

import java.util.Scanner;

public class Ejercicio4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num;
	
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Introduzca un n�mero: ");
		num=Integer.parseInt(sc.nextLine());
		
		while (num%5!=0) {
			num=num + 1;
		}
		System.out.println("------------------------------------------------");
		System.out.println("los 10 siguientes n�meros que son m�ltiplos de 5: ");
		System.out.println("------------------------------------------------");
		System.out.println(num);
		
		for(int i=1; i<=9; i++) {
			num = num + 5;
			System.out.println(num);
			
		}
		
		System.out.println("=================================================");	
		
		sc.close();
	}

}
