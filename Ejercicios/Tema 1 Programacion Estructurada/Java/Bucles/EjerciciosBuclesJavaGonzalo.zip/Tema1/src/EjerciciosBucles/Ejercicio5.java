package EjerciciosBucles;

import java.util.Scanner;

public class Ejercicio5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num;
		
		Scanner sc = new Scanner(System.in);
		
		//INICIO
		
		System.out.println("Introduce un n�mero: ");
		num=Integer.parseInt(sc.nextLine());
		
		while(num!=0){
			
			if (num%2==0) {
				
				System.out.println("Es par ");
			}
			
			if (num>0) {
				
				System.out.println("Es positivo ");
			}
			
			System.out.println("El cuadrado de " + num + " es " + num*num);
			
			System.out.println("Introduce un n�mero: ");
			num=Integer.parseInt(sc.nextLine());
		
		}
		
		sc.close();

	}

}
